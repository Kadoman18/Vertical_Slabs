console.warn("Copper Slabs script loaded!");
import "./copper_behavior.js"