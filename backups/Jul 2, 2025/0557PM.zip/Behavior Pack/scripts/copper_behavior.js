import {
  world,
  BlockPermutation,
  MinecraftEnchantmentTypes
} from "@minecraft/server";
// Mapping of Oxidization Progression
const oxidizeMap = {
  "kado:cut_copper_vertical_slab": "kado:exposed_cut_copper_vertical_slab",
  "kado:exposed_cut_copper_vertical_slab": "kado:weathered_cut_copper_vertical_slab",
  "kado:weathered_cut_copper_vertical_slab": "kado:oxidized_cut_copper_vertical_slab"
};
// Reverse Mapping for De-Oxidization
const deoxidizeMap = Object.fromEntries(
  Object.entries(oxidizeMap).map(([from, to]) => [to, from])
);
// Waxing and De-Waxing Maps
const waxMap = {
  "kado:cut_copper_vertical_slab": "kado:waxed_cut_copper_vertical_slab",
  "kado:exposed_cut_copper_vertical_slab": "kado:waxed_exposed_cut_copper_vertical_slab",
  "kado:weathered_cut_copper_vertical_slab": "kado:waxed_weathered_cut_copper_vertical_slab",
  "kado:oxidized_cut_copper_vertical_slab": "kado:waxed_oxidized_cut_copper_vertical_slab"
};
const unwaxMap = Object.fromEntries(Object.entries(waxMap).map(([k, v]) => [v, k]));
// All Vanilla Axe Type IDs
const axeIds = [
  "minecraft:wooden_axe",
  "minecraft:stone_axe",
  "minecraft:iron_axe",
  "minecraft:diamond_axe",
  "minecraft:netherite_axe",
  "minecraft:golden_axe"
];
// Reduce Durability Based on Unbreaking Enchantment
function damageAxe(item) {
  if (!item || !axeIds.includes(item.typeId)) return;
  const enchantments = item.getComponent("minecraft:enchantments")?.enchantments;
  const unbreakingLevel = enchantments?.getEnchantment(MinecraftEnchantmentTypes.unbreaking)?.level ?? 0;
  const ignoreChance = 1 / (unbreakingLevel + 1);
  if (Math.random() < ignoreChance) {
    item.damage += 1;
  }
}
// Unified Custom Component Behavior
const copperBehaviorComponent = {
  // Oxidization Logic (Triggered by minecraft:tick)
  onTick({ block }) {
    const currentId = block.typeId;
    const nextId = oxidizeMap[currentId];
    if (!nextId) return;
    const state = block.permutation.getAllStates();
    const newPerm = BlockPermutation.resolve(nextId, state);
    block.setPermutation(newPerm);
  },
  // Interaction Logic for Waxing, De-Waxing, and De-Oxidizing
  onPlayerInteract({ block, player }) {
    const container = player.getComponent("minecraft:inventory")?.container;
    const item = container?.getItem(player.selectedSlot);
    if (!item) return;
    const currentId = block.typeId;
    const state = block.permutation.getAllStates();
    const isAxe = axeIds.includes(item.typeId);
    const isHoneycomb = item.typeId === "minecraft:honeycomb";
    // Waxing Logic
    if (isHoneycomb && waxMap[currentId]) {
      block.setPermutation(BlockPermutation.resolve(waxMap[currentId], state));
      player.playSound("copper.wax.on", { location: player.location });
      item.amount -= 1;
      return;
    }
    // De-Waxing Logic
    if (isAxe && unwaxMap[currentId]) {
      block.setPermutation(BlockPermutation.resolve(unwaxMap[currentId], state));
      player.playSound("copper.wax.off", { location: player.location });
      damageAxe(item);
      return;
    }
    // De-Oxidization Logic
    if (isAxe && deoxidizeMap[currentId]) {
      block.setPermutation(BlockPermutation.resolve(deoxidizeMap[currentId], state));
      player.playSound("copper.wax.off", { location: player.location });
      damageAxe(item);
    }
  }
};
// Component Registration Hook
world.beforeEvents.worldInitialize.subscribe(({ blockComponentRegistry }) => {
  blockComponentRegistry.registerCustomComponent("kado:copper_behavior", copperBehaviorComponent);
});
